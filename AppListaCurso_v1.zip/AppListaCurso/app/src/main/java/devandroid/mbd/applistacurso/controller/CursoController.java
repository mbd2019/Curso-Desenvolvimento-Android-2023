package devandroid.mbd.applistacurso.controller;

public class CursoController {
}
