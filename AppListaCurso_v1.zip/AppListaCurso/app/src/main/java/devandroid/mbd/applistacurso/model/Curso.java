package devandroid.mbd.applistacurso.model;

public class Curso {
}
